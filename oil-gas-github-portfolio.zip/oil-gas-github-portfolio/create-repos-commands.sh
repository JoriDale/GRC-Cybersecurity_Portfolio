#!/usr/bin/env bash
# Run this from the folder containing the six project folders.
# Requires GitHub CLI: https://cli.github.com/

for repo in 01-ai-governance-policy-framework 02-risk-assessment-template 03-security-awareness-program 04-incident-response-plan 05-vendor-risk-assessment 06-nist-csf-mapping-project; do
  cd "$repo" || exit 1
  git init
  git add .
  git commit -m "Initial oil and gas GRC portfolio project"
  gh repo create "$repo" --public --source=. --remote=origin --push
  cd ..
done
