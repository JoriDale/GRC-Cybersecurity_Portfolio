# AI Use Case Intake Template

| Field | Response |
|---|---|
| Use Case Name | |
| Business Unit | Upstream / Midstream / Downstream / Corporate |
| Process Supported | |
| AI Type | Generative AI / ML / Computer Vision / Optimization / Other |
| Data Used | |
| Data Classification | Public / Internal / Confidential / Restricted |
| Operational Impact | None / Low / Medium / High / Safety Critical |
| Human Reviewer | |
| Vendor Involved | Yes / No |
| Expected Benefit | |
| Key Risks | |
| Required Controls | |
| Approval Decision | Approved / Approved with Conditions / Rejected |
