# Security Awareness Program — Oil & Gas Portfolio Project

## Project Purpose
Role-based security awareness for corporate, field, refinery, pipeline, and OT personnel.

## Industry Scenario
A fictional integrated oil and gas company operates upstream production sites, midstream pipeline assets, refinery operations, corporate IT, cloud analytics, and third-party services. This project creates a practical artifact that could be reviewed by security, risk, operations, and audit teams.

## What This Demonstrates
- Oil and gas sector awareness
- Governance, risk, and compliance thinking
- OT/ICS and enterprise cybersecurity alignment
- Practical documentation and executive communication
- NIST CSF 2.0 alignment where applicable

## Folder Structure
- `docs/` — main project documentation
- `templates/` — editable templates and checklists
- `examples/` — filled-in examples for a fictional oil and gas company
- `assets/` — diagrams, tables, or supporting materials

## How to Use
1. Read the main document in `docs/`.
2. Review the template in `templates/`.
3. Compare against the example in `examples/`.
4. Customize the project for upstream, midstream, downstream, or corporate use cases.

## Disclaimer
Portfolio project only. Validate against actual regulatory, operational, safety, and legal requirements before real-world use.
