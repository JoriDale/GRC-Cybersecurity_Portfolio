# Incident Report Template

| Field | Response |
|---|---|
| Incident ID | |
| Date/Time Detected | |
| Reporter | |
| Business Unit / Site | |
| Systems Affected | |
| IT/OT/Cloud/AI/Vendor | |
| Initial Severity | |
| Description | |
| Safety Impact | |
| Production Impact | |
| Data Impact | |
| Containment Actions | |
| Evidence Preserved | |
| External Notifications Needed | |
| Current Status | |
| Lessons Learned | |
