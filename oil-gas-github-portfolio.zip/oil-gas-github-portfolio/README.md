# Oil & Gas Cybersecurity, AI Governance, and GRC Portfolio

This portfolio is designed as a sequence of six GitHub projects for the oil and gas industry. The projects move from governance to assessment, training, response, third-party risk, and framework mapping. Together they demonstrate practical GRC, cybersecurity, OT security, and AI governance skills for upstream, midstream, downstream, and corporate environments.

## Sequence

1. **AI Governance Policy Framework** — establishes how AI can be used safely in exploration, production, pipeline, refinery, HSE, and business workflows.
2. **Risk Assessment Template** — identifies and scores cybersecurity, operational technology, data, safety, and AI risks.
3. **Security Awareness Program** — translates risk into role-based awareness for executives, engineers, operators, field teams, and contractors.
4. **Incident Response Plan** — defines response playbooks for ransomware, SCADA disruption, cloud compromise, vendor incidents, and data exposure.
5. **Vendor Risk Assessment** — evaluates third-party cyber, OT, cloud, AI, and operational resilience risks.
6. **NIST CSF Mapping Project** — maps the portfolio to NIST CSF 2.0 Govern, Identify, Protect, Detect, Respond, and Recover outcomes.

## Suggested GitHub Repo Naming

- `oil-gas-ai-governance-framework`
- `oil-gas-cyber-risk-assessment-template`
- `oil-gas-security-awareness-program`
- `oil-gas-incident-response-plan`
- `oil-gas-vendor-risk-assessment`
- `oil-gas-nist-csf-mapping`

## Disclaimer

These are portfolio templates, not legal, regulatory, engineering, or emergency-response advice. Real oil and gas environments should validate controls with cybersecurity, safety, operations, legal, compliance, and engineering stakeholders.
